# Description

In the underbelly of the grand city of Caledonia, a forgotten world of commerce thrived. The Dwarf Banks, a network of ancient financial institutions run by the dwarven folk, remained concealed from the human world, driven underground in the wake of towering skyscrapers and the ceaseless hum of digital transactions. Among them, the Giancardi Bank, once the crown jewel of the dwarf economy, had been struggling. At the brink of the 21st century, the bank had found itself far behind the advances of the human world.

During a sunny monday morning, The project's owner was suprised with a promotion, he was never seen after that day. WHAT HAPPENED TO HIM? OO


FLAG=Securinets{REDACTED}
PORT: 3000